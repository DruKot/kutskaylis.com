
    <div id="footer">
        <p>All rights reserved © 2014 <a href="http://site5">kutskaylis.com</a></p>
    </div>

</body>
</html>