<html>
<head>
    <title>Kutskaylis</title>
    <link rel="shortcut icon" href="<?=$this->config->site_url();?>data/img/32.ico" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="<?=$this->config->site_url();?>data/css/style.css" type="text/css" />
    <script type="text/javascript" src="/data/js/jquery.js"></script>
</head>
<body>
    <div id="logo"><?=anchor('',' ')?></div>
