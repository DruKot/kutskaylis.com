
<div id="content">
    <?php 
        if(isset ($content))
            echo $content;
        else
            echo '<h1>Пустая страница</h1>';
    ?>
</div>
